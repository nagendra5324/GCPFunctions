
def test_method():
	print("Hello")